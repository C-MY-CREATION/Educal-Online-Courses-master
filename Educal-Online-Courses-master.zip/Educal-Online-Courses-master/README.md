Demo : https://648da51c0335767fb168d47c--clinquant-lebkuchen-d976ba.netlify.app/ 
![screencapture-localhost-3000-2023-06-17-18_04_20](https://github.com/sunil9813/Educal-Online-Courses/assets/67497228/85282c81-9851-4cb5-8c6b-65053c582fa5)
